export const DEFAULT_WEBSITE_URL = "https://skillmark-dannylabs.hushed-prawn-8015.chatgpt.site";
